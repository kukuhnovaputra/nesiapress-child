<?php
/**
 * NesiaPress child theme functions.
 *
 * This file is used to custom PHP function from NesiaPress core theme
 */

//  Add your custom function here